package state;

import model.Car;

import java.util.ArrayList;
import java.util.List;

public class EdgeTraffic {
    
    public List<Car> carsRunning = new ArrayList<>();
    public List<Car> carsWaiting = new ArrayList<>();

}
